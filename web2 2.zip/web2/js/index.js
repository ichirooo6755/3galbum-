/*
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   📷 画像ライブラリ - 使い方                                       ║
║                                                                   ║
║   下の IMAGE_DATA 配列に画像情報を追加するだけ！                    ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 🖼️ ここに画像データを追加
// ============================================================
// ============================================================
// 🖼️ 画像データ生成
// ============================================================
// ============================================================
// 🖼️ 画像データ
// data.js で IMAGE_DATA が定義されています
// ============================================================
let imageData = [];
if (typeof IMAGE_DATA !== 'undefined') {
    imageData = IMAGE_DATA;
} else {
    console.warn("IMAGE_DATA not found, initializing empty");
}

// ============================================================
// 設定俺が神やねんな
// ============================================================
const CONFIG = {
  // 一度に表示する画像数
  BATCH_SIZE: 50,

  // カテゴリの絵文字
  CATEGORY_EMOJI: {
    "A": "🅰️",
    "B": "🅱️",
    "C": "©️"
  },

  // デフォルト
  DEFAULT_EMOJI: "📁",
};

// ============================================================
// 🔧 システムコード
// ============================================================

// データを正規化
function normalizeImageData(data) {
  return data.map((img, index) => ({
    id: index + 1,
    url: img.url,
    thumbnail: img.thumbnail || img.url,
    title: img.title || `画像 #${index + 1}`,
    category: img.category || "未分類",
    dateRaw: img.date, // ソート用、イベント判定用
    date: new Date(img.date || Date.now()),
    event: (typeof getEventName === 'function') ? getEventName(img.date) : "Other", // イベント割り当て
  }));
}

// カテゴリ取得
function getCategoryEmoji(category) {
  return CONFIG.CATEGORY_EMOJI[category] || CONFIG.DEFAULT_EMOJI;
}

// カテゴリ一覧を抽出してセレクトボックスに追加
function populateCategoryFilter(images) {
  const categories = [...new Set(images.map((img) => img.category))].sort();
  const select = document.getElementById("categoryFilter");

  categories.forEach((cat) => {
    const option = document.createElement("option");
    option.value = cat;
    option.textContent = `${getCategoryEmoji(cat)} ${cat}`;
    select.appendChild(option);
  });
}

// 全画像データ
let allImages = normalizeImageData(imageData);
let filteredImages = [...allImages];
let displayedCount = 0;

// DOM要素
const imageGrid = document.getElementById("imageGrid");
const categoryFilter = document.getElementById("categoryFilter");
const dateSort = document.getElementById("dateSort");
const categorySort = document.getElementById("categorySort");
const searchInput = document.getElementById("searchInput");
const imageCount = document.getElementById("imageCount");
const loadingStatus = document.getElementById("loadingStatus");
const loadMoreBtn = document.getElementById("loadMoreBtn");
const loadMoreContainer = document.getElementById("loadMoreContainer");
const modal = document.getElementById("modal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalCategory = document.getElementById("modalCategory");
const modalDate = document.getElementById("modalDate");
const closeModalBtn = document.getElementById("closeModal");

// 画像をフィルタリング・ソート
function filterAndSortImages() {
  const categoryValue = categoryFilter ? categoryFilter.value : "all";
  const dateSortValue = dateSort ? dateSort.value : "newest";
  const categorySortValue = categorySort ? categorySort.value : "none";
  const searchValue = searchInput ? searchInput.value.toLowerCase() : "";

  // フィルタリング
  filteredImages = allImages.filter((img) => {
    const matchCategory =
      categoryValue === "all" || img.category === categoryValue;
    const matchSearch =
      searchValue === "" ||
      img.title.toLowerCase().includes(searchValue) ||
      img.category.toLowerCase().includes(searchValue);
    return matchCategory && matchSearch;
  });

  // ソート
  filteredImages.sort((a, b) => {
    // イベント順
    if (categorySortValue === "event") {
        const eventA = a.event || "Other";
        const eventB = b.event || "Other";
        const compare = eventA.localeCompare(eventB, "ja");
        if (compare !== 0) return compare;
    }
    
    // カテゴリ順
    if (categorySortValue === "asc" || categorySortValue === "desc") {
      const catCompare = a.category.localeCompare(b.category, "ja");
      if (catCompare !== 0) {
        return categorySortValue === "asc" ? catCompare : -catCompare;
      }
    }

    // 次に日付でソート
    if (dateSortValue === "newest") {
      return b.date - a.date;
    } else {
      return a.date - b.date;
    }
  });

  displayedCount = 0;
  if (imageGrid) {
    imageGrid.innerHTML = "";
    loadImages();
    updateImageCount();
  }
}

// 画像を表示
function loadImages() {
  if (!imageGrid) return;
  const fragment = document.createDocumentFragment();
  const endIndex = Math.min(
    displayedCount + CONFIG.BATCH_SIZE,
    filteredImages.length
  );

  for (let i = displayedCount; i < endIndex; i++) {
    const img = filteredImages[i];
    const card = createImageCard(img);
    fragment.appendChild(card);
  }

  imageGrid.appendChild(fragment);
  displayedCount = endIndex;

  // もっと読み込むボタンの表示制御
  if (loadMoreContainer) {
    if (displayedCount < filteredImages.length) {
      loadMoreContainer.classList.remove("hidden");
    } else {
      loadMoreContainer.classList.add("hidden");
    }
  }

  updateImageCount();
}

// 画像カードを作成
function createImageCard(img) {
  const card = document.createElement("div");
  card.className =
    "image-card bg-white rounded-lg overflow-hidden shadow-md cursor-pointer";

  const formattedDate = img.date.toLocaleDateString("ja-JP", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });

  card.innerHTML = `
        <div class="relative aspect-[4/3] bg-gray-200 skeleton">
            <img 
                data-src="${img.thumbnail}" 
                alt="${img.title}"
                class="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-300"
                loading="lazy"
            >
        </div>
        <div class="p-2">
            <p class="text-sm font-medium text-gray-800 truncate">${img.title}</p>
            <div class="flex items-center justify-between mt-1">
                <span class="text-xs text-gray-600">${getCategoryEmoji(img.category)} ${img.category}</span>
                <span class="text-xs text-blue-600">${(img.event && img.event !== 'Other') ? img.event : ''}</span>
            </div>
            <div class="text-right mt-1">
                 <span class="text-xs text-gray-500">${formattedDate}</span>
            </div>
        </div>
    `;

  // 遅延読み込み
  const imgElement = card.querySelector("img");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          imgElement.src = imgElement.dataset.src;
          imgElement.onload = () => {
            imgElement.classList.remove("opacity-0");
            imgElement.parentElement.classList.remove("skeleton");
          };
          imgElement.onerror = () => {
            imgElement.parentElement.innerHTML =
              '<div class="absolute inset-0 flex items-center justify-center text-gray-400">画像を読み込めません</div>';
            imgElement.parentElement.classList.remove("skeleton");
          };
          observer.unobserve(entry.target);
        }
      });
    },
    { rootMargin: "100px" }
  );

  observer.observe(card);

  // クリックでモーダル表示
  card.addEventListener("click", () => openModal(img));

  return card;
}

// モーダルを開く
function openModal(img) {
  if (!modal) return;
  modalImage.src = img.url;
  modalTitle.textContent = img.title;
  modalCategory.textContent = `${getCategoryEmoji(img.category)} ${
    img.category
  }`;
  modalDate.textContent = img.date.toLocaleDateString("ja-JP", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  modal.classList.remove("hidden");
  modal.classList.add("flex");
  document.body.style.overflow = "hidden";
}

// モーダルを閉じる
function closeModal() {
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  document.body.style.overflow = "";
}

// 画像数を更新
function updateImageCount() {
  if (imageCount)
    imageCount.textContent = `${filteredImages.length}枚中 ${displayedCount}枚を表示`;
}

// デバウンス関数
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// イベントリスナー
document.addEventListener("DOMContentLoaded", () => {
  if (categoryFilter)
    categoryFilter.addEventListener("change", filterAndSortImages);
  if (dateSort) dateSort.addEventListener("change", filterAndSortImages);
  if (categorySort)
    categorySort.addEventListener("change", filterAndSortImages);
  if (searchInput)
    searchInput.addEventListener("input", debounce(filterAndSortImages, 300));
  if (loadMoreBtn) loadMoreBtn.addEventListener("click", loadImages);
  if (closeModalBtn) closeModalBtn.addEventListener("click", closeModal);
  if (modal) {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });
  }
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeModal();
  });

  // 無限スクロール
  window.addEventListener("scroll", () => {
    if (displayedCount >= filteredImages.length) return;

    const scrollPosition = window.innerHeight + window.scrollY;
    const threshold = document.documentElement.offsetHeight - 500;

    if (scrollPosition >= threshold) {
      loadImages();
    }
  });

  // 初期化
  populateCategoryFilter(allImages);
  filterAndSortImages();
});
