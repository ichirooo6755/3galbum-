document.addEventListener('DOMContentLoaded', () => {
    // URLパラメータからIDを取得
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');

    if (!id) {
        showError("IDが指定されていません。");
        return;
    }

    // データの読み込み待ち（通常は同期的に読み込まれるが、安全のため）
    if (typeof getProfileById !== 'function') {
        showError("データの読み込みに失敗しました。");
        return;
    }

    const profile = getProfileById(id);

    if (!profile) {
        showError("指定されたメンバーが見つかりません。");
        return;
    }

    renderProfile(profile);
});

function renderProfile(profile) {
    const container = document.getElementById('profileContainer');
    if (!container) return;

    // 画像パスの構築 (profile.jsと同じロジック)
    const avatarUrl = `../profilepic/${profile.id}.jpg`;
    
    // 背景色やプレースホルダー用の色
    const bgColor = profile.color || '#cccccc';

    container.innerHTML = `
        <div class="md:flex">
            <!-- 左側: 写真エリア -->
            <div class="md:w-1/2 relative bg-gray-200 min-h-[400px]">
                <img 
                    src="${avatarUrl}" 
                    alt="${profile.name}" 
                    class="w-full h-full object-cover absolute inset-0"
                    onerror="this.parentElement.style.backgroundColor='${bgColor}'; this.style.display='none'; this.parentElement.innerHTML+='<div class=\\'absolute inset-0 flex items-center justify-center text-4xl text-white font-bold\\'>${profile.name.charAt(0)}</div>'"
                >
            </div>

            <!-- 右側: 情報エリア -->
            <div class="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <div class="mb-6">
                    <span class="inline-block px-3 py-1 text-xs font-semibold tracking-wide text-white uppercase bg-gray-800 rounded-full mb-2">
                        Member #${profile.id}
                    </span>
                    <h1 class="text-4xl font-bold text-gray-900 mb-1">${profile.name}</h1>
                    <p class="text-xl text-gray-500 font-light">${profile.nameEn}</p>
                </div>

                <div class="prose prose-lg text-gray-600 mb-8">
                    <p class="font-medium text-lg mb-4 text-gray-800">${profile.intro}</p>
                    <p>${profile.description || '詳細情報はまだありません。'}</p>
                </div>

                <div class="border-t border-gray-200 pt-6 mt-auto">
                    <div class="flex items-center gap-4">
                        <div class="text-sm">
                            <p class="text-gray-500">Category</p>
                            <p class="font-medium capitalize">${profile.category}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function showError(message) {
    const container = document.getElementById('profileContainer');
    if (container) {
        container.innerHTML = `
            <div class="p-12 text-center text-red-500">
                <p class="text-xl font-bold mb-2">Error</p>
                <p>${message}</p>
                <a href="./profile.html" class="inline-block mt-4 text-blue-600 hover:text-blue-800 underline">一覧に戻る</a>
            </div>
        `;
    }
}
