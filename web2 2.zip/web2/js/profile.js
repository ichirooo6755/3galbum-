// プロフィールデータは profile_data.js から読み込まれます: PROFILE_DATA
if (typeof PROFILE_DATA === 'undefined') {
    console.error("PROFILE_DATA is missing. Make sure profile_data.js is loaded.");
}

const profiles = (typeof PROFILE_DATA !== 'undefined') ? PROFILE_DATA : [];

let currentProfiles = [...profiles];

function getAvatarUrl(id) {
    // 変更点: personalpicフォルダから画像を取得
    // HTMLファイル(html/profile.html)からの相対パス(../profilepic/)
    // 画像形式は一旦.jpgと仮定。
    return `../profilepic/${id}.jpg`;
}

function createTalentCard(profile, index) {
    return `
        <a href="profile_detail.html?id=${profile.id}" class="talent-item block hover:opacity-90 transition-opacity" style="animation-delay: ${index * 0.03}s" data-id="${profile.id}" data-name="${profile.name}">
            <img src="${getAvatarUrl(profile.id)}" alt="${profile.name}" 
                class="talent-avatar"
                onerror="this.src='https://via.placeholder.com/120x120/${profile.color.slice(1)}/ffffff?text=${profile.name.charAt(0)}'">
            <p class="talent-name">${profile.name}</p>
        </a>
    `;
}

function renderProfiles(profilesToRender) {
    const grid = document.getElementById('talentGrid');
    if (!grid) return;
    grid.innerHTML = profilesToRender.map((profile, index) => createTalentCard(profile, index)).join('');
    
    const countEl = document.getElementById('memberCount');
    if (countEl) countEl.textContent = `${profilesToRender.length} members`;
}

function sortProfiles(sortType) {
    let sorted = [...currentProfiles];
    
    switch(sortType) {
        case 'name-asc':
            sorted.sort((a, b) => a.name.localeCompare(b.name, 'ja'));
            break;
        case 'name-desc':
            sorted.sort((a, b) => b.name.localeCompare(a.name, 'ja'));
            break;
        // IDソートは削除されたため、デフォルト処理に任せる
        default:
            sorted.sort((a, b) => a.id - b.id);
    }
    
    renderProfiles(sorted);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            sortProfiles(e.target.value);
        });
    }

    // Initial render
    renderProfiles(profiles);
});
