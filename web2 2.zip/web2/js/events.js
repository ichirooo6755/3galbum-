// イベント設定
// 日付(YYYY-MM-DD)とイベント名の対応定義
// 自動的にライブラリの写真をこのイベント名でグループ化します

const EVENT_MAPPING = {
    // 日付: "イベント名"
    "2025-11-22": "Autumn Photoshoot",
    "2024-10-27": "Last Year's Festival",
    "2025-10-26": "Halloween Party",
    "2025-06-23": "Summer Trip"
};

// 補助関数: 日付からイベント名を取得
function getEventName(dateString) {
    return EVENT_MAPPING[dateString] || "Other";
}
