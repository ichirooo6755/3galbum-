// 共通プロフィールデータ
// 日本語の数字変換などのユーティリティもここに含めるか、あるいはデータ生成済みで持つか。
// ここではデータ生成ロジックを共有します。

// 日本語の数字変換関数
function numberToJapanese(num) {
    const ones = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
    const tens = ['', '十', '二十', '三十'];
    
    if (num <= 0) return '';
    if (num < 10) return ones[num];
    if (num < 100) {
        const ten = Math.floor(num / 10);
        const one = num % 10;
        return tens[ten] + ones[one];
    }
    return num.toString();
}

const PROFILE_CATEGORIES = ['engineer', 'design', 'business', 'other'];
const PROFILE_COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9', '#F1948A', '#82E0AA', '#F8C471', '#D7BDE2', '#A3E4D7'];

// 35人分のプロフィールデータ
const PROFILE_DATA = Array.from({ length: 35 }, (_, i) => {
    const num = i + 1;
    const japaneseNum = numberToJapanese(num);
    return {
        id: num,
        name: `菅原 ${japaneseNum}郎`,
        nameEn: `${japaneseNum}ro Sugawara`,
        category: PROFILE_CATEGORIES[num % 4],
        intro: `メンバーNo.${num}です。よろしくお願いします。`,
        description: `これはメンバーNo.${num}の詳細プロフィールです。趣味はプログラミングとデザインです。最近はAI技術に興味を持っています。`,
        color: PROFILE_COLORS[num % PROFILE_COLORS.length]
    };
});

// ヘルパー: IDからプロフィールを取得
function getProfileById(id) {
    return PROFILE_DATA.find(p => p.id === parseInt(id));
}
